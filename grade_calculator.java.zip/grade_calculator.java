import java.util.*;
class project2
{
   public static void main(String args[])
   {
      int a[]=new int[10];
      int sum,avg,i;
      Scanner sc=new Scanner(System.in); 
      System.out.println("enter the number of subject");
      int n=sc.nextInt();
      for(i=0;i<n;i++)
      {
         a[i]=sc.nextInt();
      }
       sum=0;
       for(i=0;i<n;i++)
       {
           sum=sum+a[i];
       }
        avg=sum/n;
       int grade=avg/100;
       if(avg>=90)
        System.out.println("total marks="+sum+"average="+avg+"grade=A");
        else if(avg>=80 && avg<90)
        System.out.println("total marks="+sum+"average="+avg+"grade=B");
        else if(avg>=70 && avg<80)
        System.out.println("total marks="+sum+"average="+avg+"grade=C");
        else if(avg>=60 && avg<70)
        System.out.println("total marks="+sum+"average="+avg+"grade=D");
        else if(avg>=50 && avg<60)
        System.out.println("total marks="+sum+"average="+avg+"grade=E");
        else if(avg>=40 && avg<50)
        System.out.println("total marks="+sum+"average="+avg+"grade=F");
        else 
        {
           System.out.println("total marks="+sum+"average="+avg+"grade=F");
           System.out.println("failed in exam");
        }
 }
}
        
